=======
History
=======

0.1.0 (2021-06-09)
------------------

* First release on PyPI.
