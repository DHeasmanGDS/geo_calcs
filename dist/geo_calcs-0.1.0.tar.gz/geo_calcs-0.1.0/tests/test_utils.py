#!/usr/bin/env python

"""Tests for `geo_calcs` package."""
