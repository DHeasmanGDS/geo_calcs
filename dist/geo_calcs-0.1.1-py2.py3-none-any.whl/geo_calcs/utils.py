"""
Author                      : Drew Heasman
Date(last updated)          : 05 June 2021
Description : Code used for geological calcuations.
"""
