=====
Usage
=====

To use geo_calcs in a project::

    import geo_calcs
