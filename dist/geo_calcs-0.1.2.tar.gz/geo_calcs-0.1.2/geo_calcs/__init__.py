"""Top-level package for geo_calcs."""

__author__ = """Drew Heasman"""
__email__ = 'heasman.drew@gmail.com'
__version__ = '0.1.2'
