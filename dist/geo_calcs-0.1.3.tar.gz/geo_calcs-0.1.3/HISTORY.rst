History
=======

0.1.3 (2021-06-10)
------------------

* Added documentation with Sphinx.


0.1.2 (2021-06-10)
------------------

* Built a few tests.
* Reorganized file structures
* Ran flake8 for style corrections
* Attempted to run tox, but tox currently fails.

0.1.0 (2021-06-09)
------------------
* First release on PyPI.
